// Escuta o evento de clique no botão com o ID "btnCalcular"
document.getElementById('btnCalcular').addEventListener('click', function() {
    // Pega o ano atual
    const anoAtual = new Date().getFullYear();

    // Pega o valor inserido no campo de entrada com o ID "nascimentoInput"
    const anoNascimento = document.getElementById("nascimentoInput").value;

    // Pega o parágrafo onde o resultado será exibido, usando o ID "idadeResultado"
    const resultado = document.getElementById("idadeResultado");

    // Valida o valor inserido no campo de ano de nascimento
    if (anoNascimento === "" || anoNascimento > anoAtual || anoNascimento < 1900) {
        // Exibe uma mensagem de erro se o valor for inválido
        resultado.innerText = "Por favor, insira um ano de nascimento válido.";
    } else {
        // Calcula a idade
        const idade = anoAtual - anoNascimento;

        // Exibe o resultado da idade no parágrafo com o ID "idadeResultado"
        resultado.innerText = "Você tem: " + idade + " anos de idade.";
    }
});
