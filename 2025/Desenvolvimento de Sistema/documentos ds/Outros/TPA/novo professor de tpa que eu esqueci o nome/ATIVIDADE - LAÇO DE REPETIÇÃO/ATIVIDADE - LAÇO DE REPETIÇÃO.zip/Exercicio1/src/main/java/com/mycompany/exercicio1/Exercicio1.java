package com.mycompany.exercicio1;

public class Exercicio1 {

    public static void main(String[] args) {
        
        // Loop que começa com o número 4 e vai até 4000, incrementando de 2 em 2 (só números pares)
        for(int p = 4; p <= 4000; p += 2){
            
            // Mostra o número atual (que sempre será par)
            System.out.println("Número: " + p);
        }
        
    }
}
