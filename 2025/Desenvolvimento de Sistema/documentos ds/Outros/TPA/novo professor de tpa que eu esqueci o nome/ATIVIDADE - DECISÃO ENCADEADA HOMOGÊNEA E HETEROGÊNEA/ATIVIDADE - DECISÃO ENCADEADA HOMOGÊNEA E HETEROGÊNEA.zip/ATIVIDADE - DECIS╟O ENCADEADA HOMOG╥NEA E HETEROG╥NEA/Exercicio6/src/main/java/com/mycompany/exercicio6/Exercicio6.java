
package com.mycompany.exercicio6;

import java.util.Scanner;

public class Exercicio6 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Pede ao usuário que digite a idade do nadador
        System.out.println("Digite a idade do nadador: ");
        int idade = scanner.nextInt();
        
         //ve em qual condição a idade se encaixa
        if(5 <= idade && idade <= 7){
            System.out.println("Infantil A");
        }
        else if(8 <= idade && idade <= 10){
            System.out.println("Infantil B");
        }
         else if(11 <= idade && idade <= 13){
            System.out.println("Juvenil A");
        }
        else if(14 <= idade && idade <= 17){
            System.out.println("Juvenil B");
        }
        else if(18 <= idade){
            System.out.println("Senior");
        }
        else{
            System.out.println("Idade insuficiente. É necessario ter, no mínimo, 5 anos de idade para ser classificado.");
        }
    }
}
