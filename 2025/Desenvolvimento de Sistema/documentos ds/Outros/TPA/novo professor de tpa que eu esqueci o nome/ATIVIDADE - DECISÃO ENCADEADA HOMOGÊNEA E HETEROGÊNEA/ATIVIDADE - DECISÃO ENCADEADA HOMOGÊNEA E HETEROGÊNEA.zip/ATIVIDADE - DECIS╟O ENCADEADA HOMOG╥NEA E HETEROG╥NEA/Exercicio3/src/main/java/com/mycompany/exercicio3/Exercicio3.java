
package com.mycompany.exercicio3;

import java.util.Scanner;

public class Exercicio3 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Mostra as opções disponiveis para o usuario
        System.out.println("Opções disponíveis para escolha: ");
        System.out.println("1 - BigMac");
        System.out.println("2 - Quarteirão");
        System.out.println("3 - MacChicken");
        System.out.println("4 - Cheddar");
        System.out.println("5 - Cheese Burger");
        
        // Pede ao usuário que digite o número do item que desejada
        System.out.println("Digite o numero correspondente a opção desejada: ");
        int opcao = scanner.nextInt();
        
        // Processa a escolha do usuario atraves da estrutura switch-case
        switch(opcao){
            
            case 1:
                // Caso o usuario tenha escolhido a opçao 1
                System.out.println("BigMac");
                break;
            case 2:
                // Caso o usuario tenha escolhido a opçao 2
                System.out.println("Quarteirão");
                break;
            case 3:
                System.out.println("MacChicken");
                break;
            case 4:
                System.out.println("Cheddar");
                break;
            case 5:
                System.out.println("Cheese Burger");
                break;  
            
            // Caso o usuário tenha digitado uma opçao invalida
            default:
                System.out.println("Opção inválida");
                break;
        }
    }
}
